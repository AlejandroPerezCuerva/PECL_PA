
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;

/**
 *
 * @author aleja
 */
public class SalaDescanso {

    private JTextArea colaSalaDescanso;
    private BlockingQueue colaSala = new LinkedBlockingDeque();
    private BlockingQueue pacientesObservacion;
    private FileWriter fichero;

    public SalaDescanso(JTextArea colaSalaDescanso, BlockingQueue pacientesObservacion, FileWriter fichero) {
        this.colaSalaDescanso = colaSalaDescanso;
        this.pacientesObservacion=pacientesObservacion;
        this.fichero=fichero;
    }

    //Añadimos los sanitarios a la sala de Descanso
    public void cambiarseSanitario(Sanitario sanitario) {
        String mensaje="El sanitario " + sanitario + " empieza a cambiarse\n";
        System.out.println(mensaje);
        try {
            fichero.write(mensaje);
            fichero.flush();
        } catch (IOException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            //Primero se meten, hacen el sleep y luego salen a sus puestos
            colaSala.put(sanitario);
            colaSalaDescanso.setText(colaSala.toString());
            sleep((int) (2000 * Math.random() + 1000)); //Sleep de 1 a 3 segundos que es lo que tardan en cambiarse
            colaSala.take();
            colaSalaDescanso.setText(colaSala.toString()); //Se actualiza el JTextFiel con los Sanitarios que han ido saliendo
        } catch (Exception e) {
        }
        mensaje="El sanitario " + sanitario + " termina de cambiarse\n";
        System.out.println(mensaje);
        try {
            fichero.write(mensaje);
            fichero.flush();
        } catch (IOException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void descansoAuxiliares(Auxiliar auxiliar, int maximo, int minimo) {
        String mensaje="El auxiliar " + auxiliar + " comienza su descanso\n";
        System.out.println(mensaje);
        try {
            fichero.write(mensaje);
            fichero.flush();
        } catch (IOException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            colaSala.put(auxiliar); //Metemos el auxiliar en la cola
            colaSalaDescanso.setText(colaSala.toString());
            sleep((int) ((maximo - minimo) * Math.random() + minimo)); //Dormimos al auxiliar el tiempo que nos indican
            colaSala.take();
            colaSalaDescanso.setText(colaSala.toString()); //Actualizamos la cola 
        } catch (InterruptedException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
        mensaje="El auxiliar " + auxiliar + " termina su descanso\n";
        System.out.println(mensaje);
        try {
            fichero.write(mensaje);
        } catch (IOException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void descansoSanitarios(Sanitario sanitario, int maximo, int minimo){
        String mensaje="El sanitario " + sanitario + " empieza su descanso\n";
        System.out.println(mensaje);
        try {
            fichero.write(mensaje);
            fichero.flush();
        } catch (IOException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            //Primero se meten, hacen el sleep y luego salen a sus puestos
            colaSala.put(sanitario);
            colaSalaDescanso.setText(colaSala.toString());
            sleep((int) ((maximo-minimo) * Math.random() + minimo)); //Sleep de 5 a 8 segundos que es lo que tardan en descansar
            colaSala.take();
            colaSalaDescanso.setText(colaSala.toString()); //Se actualiza el JTextFiel con los Sanitarios que han ido saliendo
        } catch (Exception e) {}
        mensaje="El sanitario " + sanitario + " termina su descanso\n";
        System.out.println(mensaje);        
        try {
            fichero.write(mensaje);
            fichero.flush();
        } catch (IOException ex) {
            Logger.getLogger(SalaDescanso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String toArray(){
        String colaDescanso;
        colaDescanso=colaSalaDescanso.getText();
        
        return colaDescanso;
    }
}
