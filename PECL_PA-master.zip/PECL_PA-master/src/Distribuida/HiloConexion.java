package Distribuida;

import Principal.Recepcion;
import Principal.SalaObservacion;
import Principal.SalaDescanso;
import Principal.SalaVacunacion;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aleja
 */
public class HiloConexion extends Thread {

    private Socket conexion;
    private DataInputStream entradaBooleano, entradaBoton, entradaInformar;
    private boolean boleanoBotones = false, clienteInformar = false;
    private int puestoBoton = 0;
    private Recepcion recepcion;
    private SalaVacunacion salaVacunacion;
    private SalaObservacion salaObservacion;
    private SalaDescanso salaDescanso;
    private ArrayList<String> arrayRecepcion, arrayVacunacion, arrayObservacion;
    private String stringDescanso; //Como solo hay un JTextArea no hace falta array, con un string es suficiente
    private boolean cerrar=false;//Bool para cerrar el hilo cuando se cierre la aplicación
    private ArrayList<DataOutputStream> arraySalidasRecepcion, arraySalidasVacunacion, arraySalidasObservacion;//Arrays para poder cerrar los canales fuera de los bucles
    private DataOutputStream salidaSalidaHospital;//Para la salida no es necesario un array


    public HiloConexion(Socket conexion, Recepcion recepcion, SalaVacunacion salaVacunacion, SalaObservacion salaObservacion, SalaDescanso salaDescanso) {
        try {
            this.conexion = conexion;
            this.recepcion = recepcion;
            this.salaVacunacion = salaVacunacion;
            this.salaObservacion = salaObservacion;
            this.salaDescanso = salaDescanso;
            entradaBooleano = new DataInputStream(conexion.getInputStream());
            entradaInformar = new DataInputStream(conexion.getInputStream());
            entradaBoton = new DataInputStream(conexion.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(HiloConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void run() {
        while (!cerrar) {
            try {
                char clienteInformar = entradaInformar.readChar();

                //Recogemos todos los datos necesarios para enviar al cliente
                arrayRecepcion = recepcion.crearMensajeRecepcion();
                arrayVacunacion = salaVacunacion.crearMensajeVacunacion();
                arrayObservacion = salaObservacion.crearMensajeObservacion();
                stringDescanso = salaDescanso.crearMensajeDescanso();

                //Enviamos todos los datos al cliente
                for (int i = 0; i < arrayRecepcion.size(); i++) {
                    DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                    salida.writeUTF(arrayRecepcion.get(i));
                    arraySalidasRecepcion.add(salida);
                }

                for (int i = 0; i < arrayVacunacion.size(); i++) {
                    DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                    salida.writeUTF(arrayVacunacion.get(i));
                    arraySalidasVacunacion.add(salida);
                }

                for (int i = 0; i < arrayObservacion.size(); i++) {
                    DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                    salida.writeUTF(arrayObservacion.get(i));
                    arraySalidasObservacion.add(salida);
                }

                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                salida.writeUTF(stringDescanso);
                salidaSalidaHospital=salida;

                boleanoBotones = entradaBooleano.readBoolean();
                puestoBoton = entradaBoton.readInt();
                //Si está a true es porque se ha pulsado un botón
                if (boleanoBotones) {
                    boleanoBotones = false;
                    for (int i = 0; i < 10; i++) {
                        if (puestoBoton == i + 1) {
                            //Si esto ocurre hay que cerrar la sala del sanitario que está en el puesto i
                            salaVacunacion.cerrarPuesto(i);
                        }
                    }

                }

            } catch (IOException ex) {
                Logger.getLogger(HiloConexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void cerrar() throws IOException{
        cerrar=true;//Se cambia la condición para que el hilo termine
        entradaBooleano.close();//Se cierran los canales de entrada
        entradaBoton.close();
        entradaInformar.close();
        for (int i = 0; i < arraySalidasRecepcion.size(); i++) {//Se cierran los canales de salida de Recepcion
            arraySalidasRecepcion.remove(i).close();
        }
        for (int i = 0; i < arraySalidasVacunacion.size(); i++) {//Se cierran los canales de salida de Vacunacion
            arraySalidasVacunacion.remove(i).close();
        }
        for (int i = 0; i < arraySalidasObservacion.size(); i++) {//Se cierran los canales de salida de Observacion
            arraySalidasObservacion.remove(i).close();
        }
        salidaSalidaHospital.close();//Se cierra el canal de salida de la salida del Hospital
        conexion.close();
    }
}
