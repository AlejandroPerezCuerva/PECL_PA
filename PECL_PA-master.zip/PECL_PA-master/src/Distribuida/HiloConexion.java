package Distribuida;


import Principal.Recepcion;
import Principal.SalaObservacion;
import Principal.SalaDescanso;
import Principal.SalaVacunacion;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aleja
 */
public class HiloConexion extends Thread{
    private ServerSocket server;
    private Socket conexion;
    private DataOutputStream salida;
    private DataInputStream entrada;
    private Recepcion recepcion;
    private SalaVacunacion salaVacunacion;
    private SalaObservacion salaObservacion;
    private SalaDescanso salaDescanso ;
    private ArrayList <String> arrayRecepcion, arrayVacunacion, arrayObservacion, arrayDescanso;
    
    
    
    public HiloConexion(Socket conexion, Recepcion recepcion, SalaVacunacion salaVacunacion, SalaObservacion salaObservacion, SalaDescanso salaDescanso ){
        try {
            this.server=new ServerSocket(5000);
        } catch (IOException ex) {
            Logger.getLogger(HiloConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.conexion=conexion;
        this.recepcion=recepcion;
        this.salaVacunacion=salaVacunacion;
        this.salaObservacion=salaObservacion;
        this.salaDescanso=salaDescanso;
    }
    
    
    public void run(){
        while(true){
            try {
                conexion= server.accept();
                entrada = new DataInputStream(conexion.getInputStream());// Se abre el canal de entrada
                
                salida = new DataOutputStream(conexion.getOutputStream());//Se abre el canal de salida
                int numeroPuesto=entrada.readInt()+1;//Se suma 1 ya que empieza en posición 0
                salida.writeUTF("texto");//Se envia el contenido de un puesto de vacunacion
                 } catch (IOException ex) {
                Logger.getLogger(HiloConexion.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try{
                sleep(1000);    //Se actualiza cada segundo
            }catch(Exception e){}
            }
        }
    }
/*

      try{
            servidor = new ServerSocket(5000);//Se crea el serverSocket con puerto 5000
            while(true){
                conexion = servidor.accept(); //Se espera a una nueva conexión
                
                
                entrada = new DataInputStream(conexion.getInputStream());// Se abre el canal de entrada
                salida = new DataOutputStream(conexion.getOutputStream());//Se abre el canal de salida
                int numeroPuesto=entrada.readInt()+1;//Se suma 1 ya que empieza en posición 0
                String respuesta=puestosVacunacion.get(numeroPuesto).toString();
                salida.writeUTF(respuesta);//Se envia el contenido de un puesto de vacunacion
            }
        }catch(Exception e){
            System.out.println(e);
        }
*/