/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Distribuida;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Alvaro Gonzalez Garcia
 */
public class HiloClient extends Thread {

    private ArrayList<DataInputStream> arrayEntradas = new ArrayList<>();
    private ArrayList<JTextField> arrayJTexField;
    private Socket cliente;
    private JTextArea colaRecepcion, colaSalaDescanso;
    private DataOutputStream salida;
    private JButton botonRefrescar;
    private boolean cerrar=false;//Bool para cerrar el hilo al cerrar la aplicación

    public HiloClient(Socket cliente, ArrayList<JTextField> arrayJTexField, JTextArea colaRecepcion, JTextArea colaSalaDescanso, JButton botonRefrescar) {
        this.cliente = cliente;
        this.arrayJTexField = arrayJTexField;
        this.colaRecepcion = colaRecepcion;
        this.colaSalaDescanso = colaSalaDescanso;
        this.botonRefrescar = botonRefrescar;
    }

    public void run() {
        while (!cerrar) {
        for (int i = 0; i < 36; i++) {
            DataInputStream entrada = null;
            try {
                entrada = new DataInputStream(cliente.getInputStream());
                arrayEntradas.add(entrada);
            } catch (IOException ex) {
                Logger.getLogger(HiloClient.class.getName()).log(Level.SEVERE, null, ex);

            }
        }
        
           botonRefrescar.setEnabled(true);
            try {
                try {
                    //Lo que primero nos llega son los datos de la recepción
                    colaRecepcion.setText(arrayEntradas.get(0).readUTF());
                    for (int i = 0; i < arrayJTexField.size(); i++) {
                        arrayJTexField.get(i).setText(arrayEntradas.get(i + 1).readUTF());
                    }
                    //Por ultimo llega el string de la sala de descanso
                    colaSalaDescanso.setText(arrayEntradas.get(35).readUTF());
                } catch (IOException ex) {
                    Logger.getLogger(HiloClient.class.getName()).log(Level.SEVERE, null, ex);
                }
                sleep(1000);
                refrescar();
            } catch (InterruptedException ex) {
                Logger.getLogger(HiloClient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void cerrar() throws IOException{
        cerrar=true;
        /*
        sin la salida comentada no funciona el cerrar pulsando X
        */
    //    salida.close();//Se cierra el canal de salida
        for (int i = 0; i < arrayEntradas.size(); i++) {//Se cierran los canales de entrada
            arrayEntradas.get(i).close();
        }
        cliente.close();
    }
    
    public void refrescar(){
        try {
            // TODO add your handling code here:
            DataOutputStream salida;

            salida = new DataOutputStream(cliente.getOutputStream());//Se crea el canal de salida
            salida.writeChar('a');
        } catch (IOException ex) {
            Logger.getLogger(MainClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
