package Distribuida;

import Principal.Recepcion;
import Principal.SalaObservacion;
import Principal.SalaDescanso;
import Principal.SalaVacunacion;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aleja
 */
public class HiloServidor extends Thread {

    private ServerSocket server;
    private Socket conexion;
    private Recepcion recepcion;
    private SalaVacunacion salaVacunacion;
    private SalaObservacion salaObservacion;
    private SalaDescanso salaDescanso;
    private ArrayList<HiloConexion> arrayConexiones;
    private boolean cerrar=false;

    public HiloServidor(Recepcion recepcion, SalaVacunacion salaVacunacion, SalaObservacion salaObservacion, SalaDescanso salaDescanso) {
        this.recepcion = recepcion;
        this.salaVacunacion = salaVacunacion;
        this.salaObservacion = salaObservacion;
        this.salaDescanso = salaDescanso;
    }

    public void run() {
        try {
            server = new ServerSocket(5002);
            //El hilo servidor va aceptando todas las peticiones que le entran de los clientes
            while (!cerrar) {

                conexion = server.accept();
                HiloConexion connect = new HiloConexion(conexion, recepcion, salaVacunacion, salaObservacion, salaDescanso);
                connect.start();
                arrayConexiones.add(connect);
            }
        } catch (IOException ex) {
            Logger.getLogger(HiloServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cerrar() throws IOException{ 
        /*
        sin comentearios no funciona el cerrar al pulsar la X, creo que es porque conexión no es necesario cerrarla y los hilos no se muy bien
        */
        cerrar=true;
       // for (int i = 0; i < arrayConexiones.size(); i++) {
   //         arrayConexiones.remove(i).cerrar();
   //     }
   //     conexion.close();
    }
}
