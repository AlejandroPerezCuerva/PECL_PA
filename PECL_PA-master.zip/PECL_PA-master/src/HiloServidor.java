
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aleja
 */
public class HiloServidor extends Thread{
        private ServerSocket server;
        private Socket conexion;
        private Recepcion recepcion;
        private SalaVacunacion salaVacunacion;
        private SalaObservacion salaObservacion;
        private SalaDescanso salaDescanso ;
        
        public HiloServidor( Recepcion recepcion, SalaVacunacion salaVacunacion, SalaObservacion salaObservacion, SalaDescanso salaDescanso ){
            try {
                server=new ServerSocket(5000);
            } catch (IOException ex) {
                Logger.getLogger(HiloServidor.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.recepcion=recepcion;
            this.salaVacunacion=salaVacunacion;
            this.salaObservacion=salaObservacion;
            this.salaDescanso=salaDescanso;
        }
        
        public void run(){
            while(true){ 
                try {
                   conexion=server.accept();
                   HiloConexion connect=new HiloConexion (conexion, recepcion, salaVacunacion,salaObservacion, salaDescanso);
                    connect.start();
                } catch (IOException ex) {
                    Logger.getLogger(HiloServidor.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
}
